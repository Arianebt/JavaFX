package com.example.demo19;

import javafx.fxml.FXML;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;

public class HelloController {
    @FXML
    private Label welcomeText;
    @FXML
    private ListView  lstName;

    @FXML
    void initialize() {
        lstName.getItems().add("Shrey");


    }

    @FXML
    protected void onHelloButtonClick() {
        welcomeText.setText("Welcome to JavaFX Application!");

        lstName.getItems().add("khang") ;
        lstName.getItems().add("Tanuj");
    }
}